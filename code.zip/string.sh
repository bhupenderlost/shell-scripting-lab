#!/bin/bash

string1="linux"
string2="hint"

echo "String1+String2"
string3=$string1+$string2
string3+="It's a complete string"
echo $string3