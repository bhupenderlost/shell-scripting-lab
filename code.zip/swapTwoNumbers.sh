#!/bin/bash

num1=10
num2=20

echo "Before Swapping"
echo "num1 = $num1"
echo "num2 = $num2"

num3=$num1
num1=$num2
num2=$num3

echo "After Swapping"
echo "num1 = $num1"
echo "num2 = $num3"